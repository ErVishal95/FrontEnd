$(document).ready(function(){
	//initial
	$('#datacheck').load('block.html');
	
	// handle menu clicks
	$('ul#pageSubmenu li a').click(function(){
		var page = $(this).attr('href');
		alert(page);
		$('#datacheck').load(''+page+'.html');
		return false;
	});
	
});